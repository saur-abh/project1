#!/bin/bash
clear
echo "press 1 for show job"
echo "press 2 for main menu"
read show_job
case $show_job in 
1) ./list_job.sh;;

2) ./job.sh;;
esac
