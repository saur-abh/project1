clear
#!/bin/bash
echo " __   __   __   __   __           __   __   __      __   __   ___  __       ___    __        __  "
echo "/_   /  \ /  \ /  \ |__)       | /  \ |__) /__     /  \ |__) |__  |__)  /\   |  | /  \ |\ | /__  "
echo ".__/ \__/ \__/ \__/ |       \__/ \__/ |__) .__/    \__/ |    |___ |  \ /~~\  |  | \__/ | \| .__/ "
                                                                                                 

echo "Press 1 for create job"
echo "Press 2 for delete job"
echo "Press 3 for execute job"
echo "Press 4 for list  job"
echo "Press 5 for Exit"

read job
case $job in
1) ./create_job.sh;;
2) ./delete_job.sh;;
3) ./exec_job.sh;;
4) ./list_job.sh;;
5) exit
clear
esac

