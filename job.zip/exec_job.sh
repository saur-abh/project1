#!/bin/bash
clear
echo -e "\t\t\t\t\t\t\ Job Listing"

sqoop job --list
echo -e "Which job are you whant to be execute Please Enter:"
read A
sqoop job --exec $A

echo "Press 1 to delete the job"
echo "Press 2 for main menu"
echo "Press 3 for exit"
read exec_job
case $exec_job in
1) ./delete_job.sh;;
2) ./list_job.sh;;
3) exit;;
esac
