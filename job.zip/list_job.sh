#!/bin/bash
clear
echo"       _  ___  ____ ____  "
echo"      | |/ _ \| __ ) ___| "
echo"   _  | | | | |  _ \___ \ "
echo"  | |_| | |_| | |_) |__) |"
echo"   \___/ \___/|____/____/ "
                         



echo "List of Jobs"
sqoop job --list 



echo "Press 1 For Main Menu"
echo "Press 2 For Delete Job"
read opt

case $opt in
	1) ./job.sh
;;
	2) ./delete_job.sh
;;
esac
