
#!/bin/bash
clear
echo " __   __   __   __   __           __   __   __      __   __   ___  __       ___    __        __  "
echo "/_   /  \ /  \ /  \ |__)       | /  \ |__) /__     /  \ |__) |__  |__)  /\   |  | /  \ |\ | /__  "
echo ".__/ \__/ \__/ \__/ |       \__/ \__/ |__) .__/    \__/ |    |___ |  \ /~~\  |  | \__/ | \| .__/ "
                                                                                                 


set $ERR_C=1
echo -e "\t\t\t\t\t\t \033[46mPress 1 for create job\033[m\n>>>>"
read create_job
case $create_job in
1)
#echo "Whenever we create the job we define the some values"
echo -e "\t\t\t\t\t\t \033[46mDatabases Lists\033[m"
echo -e "\033[1;33m
 `mysql -u"root" -p"root"<<EOF
	show databases; 
EOF` \033[m"

echo -e "\t\t\t\t\t\t \033[46mDefine sqlserver Database Name\033[m"
read A
echo -e "\t\t\t\t\t\t \033[46mTables name\033[m"
while [ "$ERR_C" > 0 ]
do
echo "Retype table name"
read A
result='"\033[1;33m
`mysql -u"root" -p"root" "$A" <<EOF
       show tables;
EOF` \033[m"' 

echo -e $result
if [ "$result" -eq "$A" ]
then
echo -e "\t\t\t\t\t\t \033[46mDefine Database table Name\033[m"
else
break
fi
done
read B
echo -e "\033[44mEnter sql Username\033[m"
read C
echo -e "\033[44mEnter sql Password\033[m"
read D
echo -e "\033[1;33m
`sqoop job --list`\033[m"
echo -e "\033[44mEnter job name\033[m"
read E

sqoop job --create $E -- import --connect jdbc:mysql://localhost/$A --table $B --username $C --password $D -m 1

esac

echo -e "\t\t\t\t\t\t \033[4mJob Created\033[m"
echo "Press 1 To Create Another Job"
echo "Press 2 For View Created Jobs"
echo "Press 3 For Delete Job"
echo "Press 4 For Main Menu"
read opt

case $opt in
	1) ./create_job.sh
;;
	2) ./list_job.sh
;;
	3) ./delete_job.sh
;;
	4) ./job.sh
;;
esac


