#!/bin/bash
clear
echo -e "					\e[1mJobs Lists"
echo -e "\e[32m
`sqoop job --list` "
echo -e "	\e[39m\x1b[2m		Enter job name which you want to delete\n>>>"

read A
sqoop job --delete $A
echo "Job Deleted"
echo "Press 1 To Delete Another Job"
echo "Press 2 For Main Menu"
read opt

case $opt in
	1) ./delete_job.sh
;;
	2) ./job.sh
;;
esac

